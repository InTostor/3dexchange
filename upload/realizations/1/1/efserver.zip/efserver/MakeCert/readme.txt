1. How do I create self-issued certificate for Easy File Server?
Just double click the batch file 'makecert_256.bat' to run it and answer the questions in the process, and it will create 2 files(ServerCert.pem,ServerKey.pem). Copy these 2 files into the Easy File Server folder and replace the old ones. 

2. How do I get a real certificate issued by a known CA for Easy File Server?
Just double click the batch file 'makecsr_256.bat' to run it and answer the questions in the process, and it will create 2 files(efsws_req.pem,efsws_key.pem).
Once you have your request file(CSR) 'efsws_req.pem', you just need to send it to a CA of your choice. After you get the certificates from CA, please do the following steps:
 (1.) Rename the file 'efsws_key.pem' with 'ServerKey.pem'.
 (2.) Create an empty file named 'ServerCert.pem' with Notepad, copy the content of the certificate from CA and paste it into the Notepad.
 (3.) If you get an intermediate certificate from CA, copy the content of the intermediate certificate and paste it into the Notepad under the existing content.
 (4.) If you get a root certificate from CA, copy the content of the root certificate and paste it into the Notepad under the existing content.
 (5.) Save the file 'ServerCert.pem'
 (6.) Copy these 2 files(ServerCert.pem,ServerKey.pem) into the Easy File Server folder and replace the old ones.
