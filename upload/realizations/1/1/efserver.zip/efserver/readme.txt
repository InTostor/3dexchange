Easy File Server 1.0
Easy File Server is a secure file sharing web server that allows visitors to upload/download files easily through web browser. For more information, please visit http://www.sharing-file.com
Please feel free to email us at macrogu@gmail.com if you have any questions.

1. How to run the server?
Just double click the run.bat file to run the server, and then you can login the server with a web browser by typing the server ip and port. On local server, you can type http://127.0.0.1:8080 to open the login page, for the https server, please type https://127.0.0.1:4433

2. How to login the server?
The default username/password is admin/test123, please login the server with the default username/password and then change the password immediately.

3. How to change the port and other options?
Edit the batch file run.bat with Notepad and change the value for parameter --port

Here is a list of the parameters you can set for Easy File Server:

 --help                         Display help screen
 --port                         The port number of HTTP Server
 --sslport                      The port number of HTTPS Server
 --sslcert                      The ssl certificate file for HTTPS Server
 --sslkey                      The ssl key file for HTTPS Server
 --pagedir                    The directory which contains the server page files
 --defaultpage             The default server page file, the default value is index.ssp
 --tempdir                   The directory where the upload data is saved, the default value is current directory.
 --filelog                      The log will be saved to file or not, the value is 1 or 0.
 --logpath                    The directory where the log files save in, the log file will be save in log directory by default.
 --postsize                    The max size of upload data, the data will be saved into a temp file if it exceeds the max size. The default size is 20MB
 --forcessl                     Force Http to Https or not, the value is 1 or 0.

4. How to modify the pages of the server?
The server page is created with open source scripting language Silk(http://silklang.org) which is similar to PHP, you can edit the server side page files(.ssp) in the EasyFileServer/ServerPages directory to customize it. 